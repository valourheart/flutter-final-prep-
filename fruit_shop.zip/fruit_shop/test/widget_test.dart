import 'package:flutter_test/flutter_test.dart';
import 'package:fruit_shop/main.dart';

void main() {
  testWidgets('Shows fruit names', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());
    expect(find.text('Fruit Shop'), findsOneWidget);
    expect(find.text('Apple'), findsOneWidget);
  });
}
