# Fruit Shop

A simple responsive Flutter app listing fruits with prices and a Buy Now button.

## Run
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. In this folder, generate the platform folders (android, ios, web, etc.):
   `flutter create .`
3. `flutter pub get`
4. `flutter run`

## Images
The files in `assets/` are placeholders. Replace them with your own photos,
keeping the same names: apple.jpg, orange.jpg, mango.jpg, pomeg.jpg.
