# Budget Calculator

Enter monthly income and expenses (rent/EMI, food, transport, others) to see
your remaining balance and whether you are overspending.

## Run
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. In this folder, generate the platform folders (android, ios, web, etc.):
   `flutter create .`
3. `flutter pub get`
4. `flutter run`
