import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:budget_calculator/main.dart';

void main() {
  testWidgets('Calculates remaining balance', (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(home: BudgetPage()));

    final fields = find.byType(TextField);
    await tester.enterText(fields.at(0), '50000');
    await tester.enterText(fields.at(1), '15000');
    await tester.enterText(fields.at(2), '8000');
    await tester.enterText(fields.at(3), '2000');
    await tester.enterText(fields.at(4), '5000');

    await tester.tap(find.text('Calculate Balance'));
    await tester.pump();

    expect(find.text('Remaining Balance: ₹20000.0'), findsOneWidget);
    expect(find.text('You have money remaining!'), findsOneWidget);
  });
}
