# Photo Gallery

A simple 2-column photo gallery grid in Flutter.

## Run
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. In this folder, generate the platform folders (android, ios, web, etc.):
   `flutter create .`
3. `flutter pub get`
4. `flutter run`

## Images
The files in `assets/` are placeholders. Replace them with your own photos,
keeping the same names: nature.jpg, flower.jpg, beach.jpg, mountain.jpg.
