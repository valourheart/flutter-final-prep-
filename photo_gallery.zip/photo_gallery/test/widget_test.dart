import 'package:flutter_test/flutter_test.dart';
import 'package:photo_gallery/main.dart';

void main() {
  testWidgets('Shows gallery title and labels', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());
    expect(find.text('Photo Gallery'), findsOneWidget);
    expect(find.text('Nature'), findsOneWidget);
    expect(find.text('Beach'), findsOneWidget);
  });
}
