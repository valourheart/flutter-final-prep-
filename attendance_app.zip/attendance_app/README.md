# Attendance App

Enter a student's name, register number, total classes and classes attended.
The second screen shows the attendance percentage and whether the student is
eligible for examination (75% or above).

Files: lib/main.dart, lib/home_screen.dart, lib/second_screen.dart

## Run
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. In this folder, generate the platform folders (android, ios, web, etc.):
   `flutter create .`
3. `flutter pub get`
4. `flutter run`
