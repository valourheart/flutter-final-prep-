import 'package:flutter_test/flutter_test.dart';
import 'package:attendance_app/main.dart';

void main() {
  testWidgets('Shows attendance result', (WidgetTester tester) async {
    await tester.pumpWidget(MyApp());

    final fields = find.byType(TextField);
    await tester.enterText(fields.at(0), 'Anu');
    await tester.enterText(fields.at(1), '12345');
    await tester.enterText(fields.at(2), '100');
    await tester.enterText(fields.at(3), '80');

    await tester.tap(find.text('View Attendance'));
    await tester.pumpAndSettle();

    expect(find.text('Attendance Result'), findsOneWidget);
    expect(find.textContaining('80.00%'), findsOneWidget);
    expect(find.textContaining('Eligible for Examination'), findsOneWidget);
  });
}
