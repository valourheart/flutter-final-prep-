import 'package:flutter/material.dart';

class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final data = ModalRoute.of(context)!.settings.arguments as List;

    double percentage = (int.parse(data[3]) / int.parse(data[2])) * 100;

    return Scaffold(
      appBar: AppBar(title: Text('Attendance Result')),
      body: Center(
        child: Card(
          margin: EdgeInsets.all(20),
          child: ListTile(
            leading: Icon(Icons.person),
            title: Text('Name: ${data[0]}'),
            subtitle: Text(
              'Register No: ${data[1]}\n'
              'Total Classes: ${data[2]}\n'
              'Classes Attended: ${data[3]}\n'
              'Attendance: ${percentage.toStringAsFixed(2)}%\n'
              '${percentage >= 75 ? "Eligible for Examination" : "Not Eligible for Examination"}',
            ),
          ),
        ),
      ),
    );
  }
}
