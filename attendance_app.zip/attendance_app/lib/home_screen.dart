import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  final name = TextEditingController();
  final reg = TextEditingController();
  final total = TextEditingController();
  final attended = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Attendance')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: name,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: reg,
              decoration: const InputDecoration(labelText: 'Register Number'),
            ),
            TextField(
              controller: total,
              decoration: const InputDecoration(labelText: 'Total Classes'),
            ),
            TextField(
              controller: attended,
              decoration: const InputDecoration(labelText: 'Classes Attended'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(
                  context,
                  '/second',
                  arguments: [
                    name.text,
                    reg.text,
                    total.text,
                    attended.text,
                  ],
                );
              },
              child: const Text('View Attendance'),
            ),
          ],
        ),
      ),
    );
  }
}
