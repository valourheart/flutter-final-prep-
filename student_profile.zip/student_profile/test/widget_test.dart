import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:student_profile/main.dart';

void main() {
  testWidgets('Show and hide profile', (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(home: ProfilePage()));

    AnimatedOpacity opacity() =>
        tester.widget<AnimatedOpacity>(find.byType(AnimatedOpacity));

    expect(opacity().opacity, 0);

    await tester.tap(find.text('Show Profile'));
    await tester.pump();
    expect(opacity().opacity, 1);

    await tester.tap(find.text('Hide Profile'));
    await tester.pump();
    expect(opacity().opacity, 0);
  });
}
