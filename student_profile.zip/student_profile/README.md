# Student Profile

A simple Flutter page that fades a student profile card in and out
using AnimatedOpacity.

## Run
1. Install Flutter: https://docs.flutter.dev/get-started/install
2. In this folder, generate the platform folders (android, ios, web, etc.):
   `flutter create .`
3. `flutter pub get`
4. `flutter run`
